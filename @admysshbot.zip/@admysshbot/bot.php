<?php

// PARA MAS INFO ETC CONSULTAME MAMA WEBO @GATESCCN

date_default_timezone_set ('America/Sao_Paulo'); // TIEMPO DE VPS

// NECESITADO
include __DIR__.'/Telegram.php';

if (!file_exists('dadosBot.ini')){

	echo "Instale el bot primero!";
	exit;

}

$textoMsg=json_decode (file_get_contents('textos.json'));
$iniParse=parse_ini_file('dadosBot.ini');

$ip=$iniParse ['ip'];
$token=$iniParse ['token'];
$limite=$iniParse ['limite'];

define ('TOKEN', $token); // TOKEN

// CLASES
$tlg=new Telegram (TOKEN);
$redis=new Redis ();
$redis->connect ('localhost', 6379); //redis usando puerto estándar

// BLOQUE UTILIZADO EN SONDEO LARGO

while (true){

$updates=$tlg->getUpdates();

for ($i=0; $i < $tlg->UpdateCount(); $i++){

$tlg->serveUpdate($i);

switch ($tlg->Text ()){

	case '/start':

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => $textoMsg->start,
		'parse_mode' => 'html',
		'reply_markup' => $tlg->buildInlineKeyBoard ([
			[$tlg->buildInlineKeyboardButton ('SSH Gratis', null, '/sshmanda')]
		])
	]);

	break;
	case '/sobre':

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => 'BOT MATERNIDO Y ECHO por @GATESCCN12'
	]);

	break;
	case '/total':

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => 'FUERON CREADAS <b>'.$redis->dbSize ().'</b> CUENTAS EN LAS ULTIMAS 24h',
		'parse_mode' => 'html'
	]);

	break;
	case '/sshmanda':

	$tlg->answerCallbackQuery ([
	'callback_query_id' => $tlg->Callback_ID()
	]);

	if ($redis->dbSize () == $limite){

		$textoSSH=$textoMsg->sshmanda->limite;

	} elseif ($redis->exists ($tlg->UserID ())){

		$textoSSH=$textoMsg->sshmanda->nao_criado;

	} else {

		$usuario=substr (str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 6);
		$senha=mt_rand(11111, 999999);

		exec ('./gerarusuario.sh '.$usuario.' '.$senha.' 1 1');

		$textoSSH="CUENTA SSH CREADA ;)\r\n\r\n<b>Servidor:</b> <code>".$ip."</code>\r\n<b>Usuario:</b> <code>".$usuario."</code>\r\n<b>CONTRASEÑA:</b> <code>".$senha."</code>\r\n<b>USUARIRO:</b> 1\r\n<b>Valides:</b> ".date ('d/m', strtotime('+1 day'))."\r\n\r\n🤙 cortecia de @gatesccn";

		$redis->setex ($tlg->UserID (), 72000, 'true'); //log en seg

	}

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => $textoSSH,
		'parse_mode' => 'html'
	]);

	break;

}

}}
