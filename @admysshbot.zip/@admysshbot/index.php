<?php

echo time ()-mktime (0, 0, 0, date ('n'), date ('j'), date ('Y'));